<?php
class BWGModelImage_browser {
}
jQuery(document).ready(function () {
  // press ESC hide loading.
  jQuery(document).keyup(function(e) {
     if ( e.keyCode == 27 ) {
        jQuery('#loading_div').hide();
    }
  });
  // Galleries form.
  if ( jQuery("form").hasClass("bwg_galleries") ) {
    wd_showhide_weights();
    wd_pagination();
  }

  jQuery("#check_all").on("click", function () {
    spider_check_all("#check_all");
  });

  // Add tooltip to elements with "wd-info" class.
  if ( typeof jQuery(document).tooltip != "undefined" ) {
    jQuery(document).tooltip({
      show: null,
      items: ".wd-info",
      content: function () {
        var element = jQuery(this);
        if (element.is(".wd-info")) {
          var html = jQuery('#' + jQuery(this).data("id")).html();
          return html;
        }
      },
      open: function (event, ui) {
        if (typeof(event.originalEvent) === 'undefined') {
          return false;
        }
        var $id = jQuery(ui.tooltip).attr('id');
        // close any lingering tooltips
        jQuery('div.ui-tooltip').not('#' + $id).remove();
      },
      close: function (event, ui) {
        ui.tooltip.hover(function () {
            jQuery(this).stop(true).fadeTo(400, 1);
          },
          function () {
            jQuery(this).fadeOut('400', function () {
              jQuery(this).remove();
            });
          });
      },
      position: {
        my: "center top+30",
        at: "center top",
        using: function (position, feedback) {
          jQuery(this).css(position);
          jQuery("<div>")
            .addClass("tooltip-arrow")
            .addClass(feedback.vertical)
            .addClass(feedback.horizontal)
            .appendTo(this);
        }
      }
    });
  }

	bwg_change_theme_tab_item();
	bwg_filters();
	bwg_toggle_postbox();

  jQuery(".bwg_requried").on("keypress", function () {
    jQuery(".bwg_requried").removeAttr("style");
  });

  jQuery(".wd-filter").on("change", function () {
    var form = jQuery(this).parents("form");

    var action = form.attr("action");
    action += "&paged=1";
    action += "&s=" + jQuery("input[name='s']").val();
    action += "&filter-by-gallery=" + jQuery("select[name='filter[filter-by-gallery]']").val();
    action += "&filter-by-image=" + jQuery("select[name='filter[filter-by-image]']").val();
    form.attr("action", action);

    form.submit();
  });

  // Options form.
  if (jQuery("form#bwg_options_form").length > 0) {
    jQuery(".bwg_tabs").each(function () {
      jQuery(this).tabs({
        active: jQuery('#active_tab').val(),
        activate: function( event, ui ) {
          jQuery('#active_tab').val(ui.newTab.index());
          if ( ui.newTab.index() == 1 ) {
            bwg_gallery_type_options();
          }
          else if ( ui.newTab.index() == 2 ) {
            bwg_album_type_options();
          }
        }
      });
    });
    bwg_gallery_type_options();
    bwg_album_type_options();
  }

  // Changing label Number of image rows to columns in masonry view
  jQuery('input[name=masonry]').on('click', function(){
    if(jQuery(this).val() == 'horizontal') {
      jQuery('.masonry_col_num').hide();
      jQuery('.masonry_row_num').show();
    } else {
      jQuery('.masonry_row_num').hide();
      jQuery('.masonry_col_num').show();
    }
  });

});

jQuery(window).load(function () {
  /* bwg_tb_window function changes the size of PopUp (width, height) */
  bwg_tb_window();
  /* Hide loading */
  jQuery('#loading_div.bwg_show').hide();
  // Albums form.
  if (jQuery("form").hasClass("bwg_albums")) {
    jQuery("#bwg_tabs").sortable({
      items: ".connectedSortable",
      update: function (event, tr) {
        bwg_albums_galleries();
      }
    });
    bwg_albums_galleries();
  }
});

function bwg_albums_galleries() {
  var str = '';
  jQuery("#bwg_tabs>.connectedSortable").each(function () {
    item = jQuery(this);
    str += item.attr('data-id') + ':' + item.attr('data-is-album') + ',';
  });
  jQuery("#albums_galleries").val(str);
}

function bwg_remove_album_gallery(obj) {
  jQuery(obj).closest(".connectedSortable").remove();
  bwg_albums_galleries();
}

function bwg_add_album_gallery(alb_gal_id, is_album, preview_image, name, status, tb_remove) {
  var html = jQuery('#bwg_template').html()
	  .replace(/%%alb_gal_id%%/g, alb_gal_id)
	  .replace(/%%is_album%%/g, is_album)
	  .replace(/%%preview_image%%/g, 'background-image:url(&quot;' + preview_image + '&quot;)')
	  .replace(/%%name%%/g, name)
	  .replace(/%%status%%/g, status);
  jQuery('#bwg_tabs').children('#bwg_template').last().before(html);
  bwg_albums_galleries();
  if (tb_remove != false) {
    window.parent.tb_remove();
  }
}

function spider_get_items() {
  jQuery('#tbody_albums_galleries input[type=checkbox]').each(function () {
    obj = jQuery(this);
    if (obj.attr('checked')) {
      window.parent.bwg_add_album_gallery(obj.attr('data-id'), obj.attr('data-is-album'), obj.attr('data-preview-image'), obj.attr('data-name'), obj.attr('data-status'), false);
    }
  });
  window.parent.tb_remove();
}

function addPricelist(pricelist) {
  jQuery('#image_pricelist_id', window.parent.document).val(pricelist.id);
  window.parent.spider_set_input_value('ajax_task', 'set_image_pricelist');
  window.parent.spider_ajax_save('bwg_gallery');
  window.parent.tb_remove();
}

function bwg_remove_pricelist(obj) {
  jQuery("#remove_pricelist").val(jQuery(obj).attr("data-image-id"));
  jQuery("#pricelist_id_" + jQuery(obj).attr("data-pricelist-id") ).val("");
  spider_set_input_value('ajax_task', 'remove_image_pricelist');
  spider_ajax_save('bwg_gallery');
}

var bwg_save_count = 50;
/**
 * Save gallery and images.
 *
 * @param form_id
 * @param tr_group // Save counter.
 * @returns {boolean}
 */
function spider_ajax_save(form_id, tr_group) {
  if (spider_check_required('name', 'Name') ) { return false; }
  var post_data = {};

  post_data["task"] = "save";
  var ajax_task = jQuery("#ajax_task").val();/* Images list action task.*/
  post_data["current_id"] = jQuery("#current_id").val();/* Current gallery id.*/
  post_data["image_current_id"] = jQuery("#image_current_id").val();/* Current image id.*/
  var ids_string = jQuery("#ids_string").val();/* Images ids separated by comma.*/
  post_data["image_bulk_action"] = jQuery("[name=image_bulk_action]").val(); /* Bulk action for images.*/
  post_data["s"] = jQuery("input[name='s']").val();/* Images filter.*/
  post_data["paged"] = jQuery("#paged").val();/* Images page number.*/
  post_data["bwg_nonce"] = jQuery("#bwg_nonce").val();/* Nonce*/
  post_data["image_pricelist_id"] = jQuery("#image_pricelist_id").val(); // ?????
  post_data["remove_pricelist"] = jQuery("#remove_pricelist").val(); // ?????

  // Images ids array.
  var ids_array = ids_string.split(",");
  // Images count on page.
  var tr_count = ids_array.length;

  if (!tr_group) {
    var tr_group = 1;
  }
  else if ((tr_count > bwg_save_count * tr_group)) {
    ajax_task = '';
  }

  /* Selected images ids.*/
  post_data["check"] = jQuery("[name^=check]:not([id=check_all_items]):checked").map(function (key, value) {
    //if ( ((tr_group - 1) * bwg_save_count) <= key && key < (bwg_save_count * tr_group) ) {
      return jQuery(this).attr("id").replace("check_", "");
    //}
  }).get();
  post_data["check_all_items"] = jQuery("[name=check_all_items]").is(":checked") ? 1 : 0; /* Select all.*/

  // Gallery paramters.
  post_data["name"] = jQuery("#name").val();
  post_data["slug"] = jQuery("#slug").val();
  post_data["old_slug"] = jQuery("#old_slug").val();
  post_data["preview_image"] = jQuery("#preview_image").val();
  post_data["published"] = jQuery("input[name=published]:checked").val();
  if ( (typeof tinyMCE != "undefined")
    && tinyMCE.activeEditor
    && !tinyMCE.activeEditor.isHidden()
    && tinyMCE.activeEditor.getContent ) {
    post_data["description"] = tinyMCE.activeEditor.getContent();
  }
  else {
    post_data["description"] = jQuery("#description").val();
  }
  var gallery_type_input = jQuery("#gallery_type").val();
  post_data["gallery_source"] = (gallery_type_input == 'facebook') ? jQuery("#facebook_gallery_source").val() : jQuery("#gallery_source").val();
  post_data["autogallery_image_number"] = (gallery_type_input == 'facebook') ? jQuery("#facebook_gallery_image_limit").val() : jQuery("#autogallery_image_number").val();
  post_data["update_flag"] = (gallery_type_input == 'facebook') ? jQuery("input[name=facebook_update]:checked").val() : jQuery("input[name=update_flag]:checked").val();
  var gallery_content_type = (gallery_type_input == 'facebook') ? jQuery("input[name=facebook_content_type]:checked").val() : jQuery("input[name=instagram_post_gallery]:checked").val();
  post_data["gallery_type"] = gallery_type_input + (gallery_content_type == 1 ? "_post" : "");
  post_data["gallery_type_old"] = jQuery("#gallery_type_old").val();
  post_data["instagram_post_gallery"] = gallery_content_type;
  post_data["modified_date"] = jQuery("#modified_date").val();

  // Remove images ids from begin and end of array.
  if (tr_count > bwg_save_count) {
    ids_array.splice(tr_group * bwg_save_count, ids_array.length);
    ids_array.splice(0, (tr_group - 1) * bwg_save_count);
    ids_string = ids_array.join(",");
  }

  post_data["ajax_task"] = ajax_task;
  post_data["ids_string"] = ids_string;

  // Images dimensions to resize.
  post_data["image_width"] = jQuery("#image_width").val();
  post_data["image_height"] = jQuery("#image_height").val();
  // Images bulk edit values.
  post_data["title"] = jQuery("#title").val();
  post_data["desc"] = jQuery("#desc").val();
  post_data["redirecturl"] = jQuery("#redirecturl").val();
  // Images bulk add tags ids.
  post_data["added_tags_id"] = jQuery("#added_tags_id").val();

  // Images data.
  for (var i in ids_array) {
    if (ids_array.hasOwnProperty(i) && ids_array[i]) {
      //if (jQuery("#check_" + ids_array[i]).attr('checked') == 'checked') {
      //  post_data["check_" + ids_array[i]] = jQuery("#check_" + ids_array[i]).val();
      //}
      post_data["input_filename_" + ids_array[i]] = jQuery("#input_filename_" + ids_array[i]).val();
      post_data["image_url_" + ids_array[i]] = jQuery("#image_url_" + ids_array[i]).val();
      post_data["thumb_url_" + ids_array[i]] = jQuery("#thumb_url_" + ids_array[i]).val();
      post_data["image_description_" + ids_array[i]] = jQuery("#image_description_" + ids_array[i]).val();
      post_data["image_alt_text_" + ids_array[i]] = jQuery("#image_alt_text_" + ids_array[i]).val();
      post_data["redirect_url_" + ids_array[i]] = jQuery("#redirect_url_" + ids_array[i]).val();
      post_data["input_date_modified_" + ids_array[i]] = jQuery("#input_date_modified_" + ids_array[i]).val();
      post_data["input_size_" + ids_array[i]] = jQuery("#input_size_" + ids_array[i]).val();
      post_data["input_filetype_" + ids_array[i]] = jQuery("#input_filetype_" + ids_array[i]).val();
      post_data["input_resolution_" + ids_array[i]] = jQuery("#input_resolution_" + ids_array[i]).val();
      post_data["input_crop_" + ids_array[i]] = jQuery("#input_crop_" + ids_array[i]).val();
      post_data["order_input_" + ids_array[i]] = jQuery("#order_input_" + ids_array[i]).val();
      post_data["tags_" + ids_array[i]] = jQuery("#tags_" + ids_array[i]).val();
    }
  }

  // Loading.
  jQuery("#loading_div").show();

  jQuery.post(
    jQuery('#' + form_id).attr('action'),
    post_data,
    function (data) {
      var str = jQuery(data).find("#current_id").val();
      jQuery("#current_id").val(str);
    }
  ).success(function (data, textStatus, errorThrown) {
    if (tr_count > bwg_save_count * tr_group) {
      spider_ajax_save(form_id, ++tr_group);

      return;
    }
    else {
      var form_action = jQuery(data).find('#bwg_gallery').attr("action");
      jQuery('#bwg_gallery').attr("action", form_action);
      //var str = jQuery(data).find('#bwg_gallery').html();
      //jQuery('#bwg_gallery').html(str);
      /*var current_id = jQuery(data).find("#current_id").val();
      window.history.pushState(null, null, window.location.href + '&current_id=' + current_id);*/
      var str = jQuery(data).find('.bwg-page-header').html();
      jQuery('.bwg-page-header').html(str);
      var str = jQuery(data).find('.wd-howtouse-cont').html();
      jQuery('.wd-howtouse-cont').html(str);
      var str = jQuery(data).find('.ajax-msg').html();
      jQuery('.ajax-msg').html(str);
      var str = jQuery(data).find('.gal-msg').html();
      jQuery('.gal-msg').html(str);
      var str = jQuery(data).find('.search-box').html();
      jQuery('.search-box').html(str);
      var str = jQuery(data).find('.tablenav.top').html();
      jQuery('.tablenav.top').html(str);
      var str = jQuery(data).find('#images_table').html();
      jQuery('#images_table').html(str);
      var str = jQuery(data).find('.tablenav.bottom').html();
      jQuery('.tablenav.bottom').html(str);
      var str = jQuery(data).find('.wd-hidden-values').html();
      jQuery('.wd-hidden-values').html(str);
      var str = jQuery(data).find('#task').html();
      jQuery('#task').html(str);
      var str = jQuery(data).find('#current_id').html();
      jQuery('#current_id').html(str);

      jQuery(".ajax-msg").removeClass("wd-hide");
      jQuery(".gal-msg").removeClass("wd-hide");

      jQuery(".unsaved-msg").addClass("wd-hide");

      wd_showhide_weights();
      wd_pagination();
      //bwg_toggle_postbox();
      jQuery(".how_to_postbox .hndle").each(function () {
        jQuery(this).on("click", function () {
          jQuery(this).parent(".postbox").toggleClass("closed");
        });
      });

      jQuery("#check_all").on("click", function () {
        spider_check_all("#check_all");
      });

      jQuery("#loading_div").hide();
    }
  });

  return false;
}

// Set value by id.
function spider_set_input_value(input_id, input_value) {
  if (document.getElementById(input_id)) {
    document.getElementById(input_id).value = input_value;
  }
}

// Submit form by id.
function spider_form_submit(event, form_id) {
  if (document.getElementById(form_id)) {
    document.getElementById(form_id).submit();
  }
  if (event.preventDefault) {
    event.preventDefault();
  }
  else {
    event.returnValue = false;
  }
}

// Check if required field is empty.
function spider_check_required(id, name) {
  if (jQuery('#' + id).val() == '') {
    alert(name + '* ' + bwg_objectL10B.bwg_field_required);
    jQuery('#' + id).attr('style', 'border-color: #FF0000;');
    jQuery('#' + id).focus();
    jQuery('html, body').animate({
      scrollTop:jQuery('#' + id).offset().top - 200
    }, 500);
    return true;
  }
  else {
    return false;
  }
}

/**
 * Show/hide order inputs/drag and drop columns.
 *
 * @param click
 */
function wd_showhide_weights(click) {
  if ( typeof click == "undefined" ) {
    var click = false;
  }
  if ( click ) {
    jQuery(".wd-order").toggleClass("wd-hide");
    jQuery(".wd-drag").toggleClass("wd-hide");
  }

  if ( !jQuery(".wd-drag").hasClass("wd-hide") ) { // Drag and drop.
    jQuery(".wd-order-thead").attr("title", bwg_objectL10B.bwg_show_order);
    jQuery("#tbody_arr").sortable({
      handle: ".connectedSortable",
      connectWith: ".connectedSortable",
      update: function (event, tr) {
        jQuery(".unsaved-msg").removeClass("wd-hide");
        jQuery(".ajax-msg").addClass("wd-hide");
        var i = jQuery("td.col_drag").data("page-number");
        jQuery(".wd-order").each(function () {
          jQuery(this).val(++i);
        });
      }
    });
  }
  else { // Order inputs.
    jQuery(".wd-order-thead").attr("title", bwg_objectL10B.bwg_hide_order);
  }
}

/*jQuery(".wd-check-all").on("click", function () {
  jQuery("#check_all").trigger("click");
  var checkbox = jQuery("#check_all_items");
  if (checkbox.is(":checked")) {
    checkbox.attr("checked", false);
  }
  else {
    checkbox.attr("checked", true);
  }
});*/

// Check all items.
function spider_check_all_items(event) {
  if (jQuery("#check_all_items").is(':checked')) {
    jQuery("#check_all_items").attr('checked', false);
  }
  else {
    jQuery("#check_all_items").attr('checked', true);
  }
  spider_check_all_items_checkbox(event);
}

function spider_check_all_items_checkbox(event) {
  if (jQuery("#check_all_items").is(':checked')) {
    jQuery(".ajax-msg").addClass("wd-hide");
    if (!jQuery("#check_all").is(':checked')) {
      jQuery('#check_all').trigger('click');
    }
  }
  else {
    var saved_items = (parseInt(jQuery(".displaying-num").html()) ? parseInt(jQuery(".displaying-num").html()) : 0);
    var added_items = (jQuery('input[id^="check_pr_"]').length ? parseInt(jQuery('input[id^="check_pr_"]').length) : 0);
    var items_count = added_items + saved_items;

    if (items_count) {
      jQuery(".ajax-msg")
        .html("<div class='updated inline'><p><strong>" + bwg_objectL10B.selected + ' ' + items_count + ' ' + bwg_objectL10B.item + (items_count > 1 ? "s" : "") + ".</strong></p></div>")
        .removeClass("wd-hide");
    }
    if (jQuery("#check_all").is(':checked')) {
      jQuery('#check_all').trigger('click');
    }
  }
  event.stopPropagation();
}

function spider_check_all(current) {
  if (!jQuery(current).attr('checked')) {
    jQuery('#check_all_items').attr('checked', false);
    jQuery(".ajax-msg").hide();
  }
}

// Set uploader to button class.
function spider_uploader(button_id, input_id, delete_id, img_id) {
  if (typeof img_id == 'undefined') {
    img_id = '';
  }
  jQuery(function () {
    var formfield = null;
    window.original_send_to_editor = window.send_to_editor;
    window.send_to_editor = function (html) {
      if (formfield) {
        var fileurl = jQuery('img', html).attr('src');
        if (!fileurl) {
          var exploded_html;
          var exploded_html_askofen;
          exploded_html = html.split('"');
          for (i = 0; i < exploded_html.length; i++) {
            exploded_html_askofen = exploded_html[i].split("'");
          }
          for (i = 0; i < exploded_html.length; i++) {
            for (j = 0; j < exploded_html_askofen.length; j++) {
              if (exploded_html_askofen[j].search("href")) {
                fileurl = exploded_html_askofen[i + 1];
                break;
              }
            }
          }
          if (img_id != '') {
            alert(bwg_objectL10B.bwg_select_image);
            tb_remove();
            return;
          }
          window.parent.document.getElementById(input_id).value = fileurl;
          window.parent.document.getElementById(button_id).style.display = "none";
          window.parent.document.getElementById(input_id).style.display = "inline-block";
          window.parent.document.getElementById(delete_id).style.display = "inline-block";
        }
        else {
          if (img_id == '') {
            alert(bwg_objectL10B.bwg_field_required);
            tb_remove();
            return;
          }
          window.parent.document.getElementById(input_id).value = fileurl;
          window.parent.document.getElementById(button_id).style.display = "none";
          window.parent.document.getElementById(delete_id).style.display = "inline-block";
          if ((img_id != '') && window.parent.document.getElementById(img_id)) {
            window.parent.document.getElementById(img_id).src = fileurl;
            window.parent.document.getElementById(img_id).style.display = "inline-block";
          }
        }
        formfield.val(fileurl);
        tb_remove();
      }
      else {
        window.original_send_to_editor(html);
      }
      formfield = null;
    };
    formfield = jQuery(this).parent().parent().find(".url_input");
    tb_show('', 'media-upload.php?type=image&TB_iframe=true');
    jQuery('#TB_overlay,#TB_closeWindowButton').bind("click", function () {
      formfield = null;
    });
    return false;
  });
}

// Remove uploaded file.
function spider_remove_url(button_id, input_id, delete_id, img_id) {
  if (typeof img_id == 'undefined') {
    img_id = '';
  }
  if (document.getElementById(button_id)) {
    document.getElementById(button_id).style.display = '';
  }
  if (document.getElementById(input_id)) {
    document.getElementById(input_id).value = '';
    document.getElementById(input_id).style.display = 'none';
  }
  if (document.getElementById(delete_id)) {
    document.getElementById(delete_id).style.display = 'none';
  }
  if ((img_id != '') && window.parent.document.getElementById(img_id)) {
    document.getElementById(img_id).src = '';
    document.getElementById(img_id).style.display = 'none';
  }
}

// Add album preview image.
function bwg_add_preview_image(files) {
  document.getElementById("preview_image").value = files[0]['thumb_url'];
  document.getElementById("button_preview_image").style.display = "none";
  document.getElementById("delete_preview_image").style.display = "inline-block";
  if (document.getElementById("img_preview_image")) {
    document.getElementById("img_preview_image").src = files[0]['reliative_url'];
    document.getElementById("img_preview_image").style.display = "inline-block";
  }
}

function spider_reorder_items(tbody_id) {
  jQuery("#" + tbody_id).sortable({
    handle:".connectedSortable",
    connectWith:".connectedSortable",
    update:function (event, tr) {
      spider_sortt(tbody_id);
    }
  });
}

function spider_sortt(tbody_id) {
  var str = "";
  var counter = 0;
  jQuery("#" + tbody_id).children().each(function () {
    str += ((jQuery(this).attr("id")).substr(3) + ",");
    counter++;
  });
  jQuery("#albums_galleries").val(str);
  if (!counter) {
    document.getElementById("table_albums_galleries").style.display = "none";
  }
}

function spider_remove_row(tbody_id, event, obj) {
  var span = obj;
  var tr = jQuery(span).closest("tr");
  jQuery(tr).remove();
  spider_sortt(tbody_id);
}

function spider_jslider(idtaginp) {
  jQuery(function () {
    var inpvalue = jQuery("#" + idtaginp).val();
    if (inpvalue == "") {
      inpvalue = 50;
    }
    jQuery("#slider-" + idtaginp).slider({
      range:"min",
      value:inpvalue,
      min:1,
      max:100,
      slide:function (event, ui) {
        jQuery("#" + idtaginp).val("" + ui.value);
      }
    });
    jQuery("#" + idtaginp).val("" + jQuery("#slider-" + idtaginp).slider("value"));
  });
}

/**
 * Bulk add selected tags to images.
 *
 * @param image_id
 */
function bwg_bulk_add_tags(tag_id) {
  var tagIds = "";
  if ( typeof tag_id == "undefined" ) {
    jQuery(".tags:checked").each(function () {
      tagIds += jQuery(this).data("id").toString() + ",";
    });
  }
  else {
    tagIds = tag_id;
  }
  jQuery('#added_tags_id', window.parent.document).val(tagIds);
  window.parent.spider_set_input_value('ajax_task', 'image_add_tag');
  window.parent.spider_ajax_save('bwg_gallery');
  window.parent.tb_remove();
}

/**
 * Add selected tags to image.
 *
 * @param image_id
 */
function bwg_add_tags(image_id) {
  var tagIds = [];
  var titles = [];
  jQuery(".tags:checked").each(function () {
    tagIds.push(jQuery(this).data("id").toString());
    titles.push(jQuery(this).data("name"));
  });
  window.parent.bwg_add_tag(image_id, tagIds, titles);
}

/**
 * Add tag to image.
 *
 * @param image_id
 * @param tagIds
 * @param titles
 */
function bwg_add_tag(image_id, tagIds, titles) {
  window.parent.bwg_create_loading_block();
 // Images ids array.
  var ids_array;
  if (image_id == '0') {
    var flag = false;
    var ids_string = jQuery("#ids_string").val();
    ids_array = ids_string.split(",");
    if (jQuery("#check_all_items").attr("checked")) {
      var added_tags = '';
      for (i = 0; i < tagIds.length; i++) {
        added_tags = added_tags + tagIds[i] + ',';
      }
      jQuery("#added_tags_id").val(added_tags);
    }
  }
  else {
    image_id = image_id + ',';

    ids_array = image_id.split(",");
    var flag = true;
  }
  for (var i in ids_array) {
    if (ids_array.hasOwnProperty(i) && ids_array[i]) {
      if (jQuery("#check_" + ids_array[i]).attr('checked') == 'checked' || flag) {
        image_id = ids_array[i];
        var tag_ids = document.getElementById('tags_' + image_id).value;
        tags_array = tag_ids.split(',');
        var counter = 0;
        for (i = 0; i < tagIds.length; i++) {
          if (tags_array.indexOf(tagIds[i]) == -1) { // To prevent add same tag multiple times.
            tag_ids = tag_ids + tagIds[i] + ',';
            var html = jQuery("#" + image_id + "_tag_temptagid").clone().html();
            html = html.replace(/temptagid/g, tagIds[i])
                       .replace(/temptagname/g, titles[i]);
            jQuery("#tags_div_" + image_id).append("<div class='tag_div' id='" + image_id + "_tag_" + tagIds[i] + "'>");
            jQuery("#" + image_id + "_tag_" + tagIds[i]).html(html);

            counter++;
          }
        }
        document.getElementById('tags_' + image_id).value = tag_ids;
        if (counter) {
          jQuery("#tags_div_" + image_id).removeClass("wd-hide");
        }
      }
	}
  }
  jQuery(".unsaved-msg", window.parent.document).removeClass("wd-hide");
  jQuery(".ajax-msg", window.parent.document).addClass("wd-hide");
  tb_remove();
  window.parent.bwg_remove_loading_block();
}

function bwg_remove_tag(tag_id, image_id) {
  if (jQuery('#' + image_id + '_tag_' + tag_id)) {
    jQuery('#' + image_id + '_tag_' + tag_id).remove();
    var tag_ids_string = jQuery("#tags_" + image_id).val();
    tag_ids_string = tag_ids_string.replace(tag_id + ',', '');
    jQuery("#tags_" + image_id).val(tag_ids_string);
    if (jQuery("#tags_" + image_id).val() == '') {
      jQuery("#tags_div_" + image_id).addClass("wd-hide");
    }
    jQuery(".unsaved-msg").removeClass("wd-hide");
    jQuery(".ajax-msg").addClass("wd-hide");
  }
}

function preview_watermark() {
  setTimeout(function() {
    watermark_type = window.parent.document.getElementById('watermark_type_text').checked;
    if (watermark_type) {
      watermark_text = document.getElementById('watermark_text').value;
      watermark_link = document.getElementById('watermark_link').value;
      watermark_font_size = document.getElementById('watermark_font_size').value;
      watermark_font = document.getElementById('watermark_font').value;
      watermark_color = document.getElementById('watermark_color').value;
      watermark_opacity = document.getElementById('watermark_opacity').value;
      watermark_position = jQuery("input[name=watermark_position]:checked").val().split('-');
      document.getElementById("preview_watermark").style.verticalAlign = watermark_position[0];
      document.getElementById("preview_watermark").style.textAlign = watermark_position[1];
      stringHTML = (watermark_link ? '<a href="' + watermark_link + '" target="_blank" style="text-decoration: none;' : '<span style="cursor:default;') + 'margin:4px;font-size:' + watermark_font_size + 'px;font-family:' + watermark_font + ';color:#' + watermark_color + ';opacity:' + (watermark_opacity / 100) + ';" class="non_selectable">' + watermark_text + (watermark_link ? '</a>' : '</span>');
      document.getElementById("preview_watermark").innerHTML = stringHTML;
    }
    watermark_type = window.parent.document.getElementById('watermark_type_image').checked;
    if (watermark_type) {
      watermark_url = document.getElementById('watermark_url').value;
      watermark_link = document.getElementById('watermark_link').value;
      watermark_width = document.getElementById('watermark_width').value;
      watermark_height = document.getElementById('watermark_height').value;
      watermark_opacity = document.getElementById('watermark_opacity').value;
      watermark_position = jQuery("input[name=watermark_position]:checked").val().split('-');
      document.getElementById("preview_watermark").style.verticalAlign = watermark_position[0];
      document.getElementById("preview_watermark").style.textAlign = watermark_position[1];
      stringHTML = (watermark_link ? '<a href="' + watermark_link + '" target="_blank">' : '') + '<img class="non_selectable" src="' + watermark_url + '" style="margin:0 4px 0 4px;max-width:' + watermark_width + 'px;max-height:' + watermark_height + 'px;opacity:' + (watermark_opacity / 100) + ';" />' + (watermark_link ? '</a>' : '');
      document.getElementById("preview_watermark").innerHTML = stringHTML;
    }
  }, 50);
}

function preview_built_in_watermark() {
  setTimeout(function(){
  watermark_type = window.parent.document.getElementById('built_in_watermark_type_text').checked;
  if (watermark_type) {
    watermark_text = document.getElementById('built_in_watermark_text').value;
    watermark_font_size = document.getElementById('built_in_watermark_font_size').value * 400 / 500;
    watermark_font = 'bwg_' + document.getElementById('built_in_watermark_font').value.replace('.TTF', '').replace('.ttf', '');
    watermark_color = document.getElementById('built_in_watermark_color').value;
    watermark_opacity = document.getElementById('built_in_watermark_opacity').value;
    watermark_position = jQuery("input[name=built_in_watermark_position]:checked").val().split('-');
    document.getElementById("preview_built_in_watermark").style.verticalAlign = watermark_position[0];
    document.getElementById("preview_built_in_watermark").style.textAlign = watermark_position[1];
    stringHTML = '<span style="cursor:default;margin:4px;font-size:' + watermark_font_size + 'px;font-family:' + watermark_font + ';color:#' + watermark_color + ';opacity:' + (watermark_opacity / 100) + ';" class="non_selectable">' + watermark_text + '</span>';
    document.getElementById("preview_built_in_watermark").innerHTML = stringHTML;
  }
  watermark_type = window.parent.document.getElementById('built_in_watermark_type_image').checked;
  if (watermark_type) {
    watermark_url = document.getElementById('built_in_watermark_url').value;
    watermark_size = document.getElementById('built_in_watermark_size').value;
    watermark_position = jQuery("input[name=built_in_watermark_position]:checked").val().split('-');
    document.getElementById("preview_built_in_watermark").style.verticalAlign = watermark_position[0];
    document.getElementById("preview_built_in_watermark").style.textAlign = watermark_position[1];
    stringHTML = '<img class="non_selectable" src="' + watermark_url + '" style="margin:0 4px 0 4px;max-width:95%;width:' + watermark_size + '%;" />';
    document.getElementById("preview_built_in_watermark").innerHTML = stringHTML;
  }
  }, 50);
}

function bwg_watermark(watermark_type) {
  jQuery("#" + watermark_type).attr('checked', 'checked');
  jQuery("#tr_watermark_url").css('display', 'none');
  jQuery("#tr_watermark_width_height").css('display', 'none');
  jQuery("#tr_watermark_opacity").css('display', 'none');
  jQuery("#tr_watermark_text").css('display', 'none');
  jQuery("#tr_watermark_link").css('display', 'none');
  jQuery("#tr_watermark_font_size").css('display', 'none');
  jQuery("#tr_watermark_font").css('display', 'none');
  jQuery("#tr_watermark_color").css('display', 'none');
  jQuery("#tr_watermark_position").css('display', 'none');
  jQuery("#tr_watermark_preview").css('display', 'none');
  jQuery("#preview_watermark").css('display', 'none');
  switch (watermark_type) {
    case 'watermark_type_text':
    {
      jQuery("#tr_watermark_opacity").css('display', '');
      jQuery("#tr_watermark_text").css('display', '');
      jQuery("#tr_watermark_link").css('display', '');
      jQuery("#tr_watermark_font_size").css('display', '');
      jQuery("#tr_watermark_font").css('display', '');
      jQuery("#tr_watermark_color").css('display', '');
      jQuery("#tr_watermark_position").css('display', '');
      jQuery("#tr_watermark_preview").css('display', '');
      jQuery("#preview_watermark").css('display', 'table-cell');
      break;
    }
    case 'watermark_type_image':
    {
      jQuery("#tr_watermark_url").css('display', '');
      jQuery("#tr_watermark_link").css('display', '');
      jQuery("#tr_watermark_width_height").css('display', '');
      jQuery("#tr_watermark_opacity").css('display', '');
      jQuery("#tr_watermark_position").css('display', '');
      jQuery("#tr_watermark_preview").css('display', '');
      jQuery("#preview_watermark").css('display', 'table-cell');
      break;
    }
  }
}

function bwg_built_in_watermark(watermark_type) {
  jQuery("#built_in_" + watermark_type).attr('checked', 'checked');
  jQuery("#tr_built_in_watermark_url").css('display', 'none');
  jQuery("#tr_built_in_watermark_size").css('display', 'none');
  jQuery("#tr_built_in_watermark_opacity").css('display', 'none');
  jQuery("#tr_built_in_watermark_text").css('display', 'none');
  jQuery("#tr_built_in_watermark_font_size").css('display', 'none');
  jQuery("#tr_built_in_watermark_font").css('display', 'none');
  jQuery("#tr_built_in_watermark_color").css('display', 'none');
  jQuery("#tr_built_in_watermark_position").css('display', 'none');
  jQuery("#tr_built_in_watermark_preview").css('display', 'none');
  jQuery("#preview_built_in_watermark").css('display', 'none');
  switch (watermark_type) {
    case 'watermark_type_text':
    {
      jQuery("#tr_built_in_watermark_opacity").css('display', '');
      jQuery("#tr_built_in_watermark_text").css('display', '');
      jQuery("#tr_built_in_watermark_font_size").css('display', '');
      jQuery("#tr_built_in_watermark_font").css('display', '');
      jQuery("#tr_built_in_watermark_color").css('display', '');
      jQuery("#tr_built_in_watermark_position").css('display', '');
      jQuery("#tr_built_in_watermark_preview").css('display', '');
      jQuery("#preview_built_in_watermark").css('display', 'table-cell');
      break;
    }
    case 'watermark_type_image':
    {
      jQuery("#tr_built_in_watermark_url").css('display', '');
      jQuery("#tr_built_in_watermark_size").css('display', '');
      jQuery("#tr_built_in_watermark_position").css('display', '');
      jQuery("#tr_built_in_watermark_preview").css('display', '');
      jQuery("#preview_built_in_watermark").css('display', 'table-cell');
      break;
    }
  }
}

function bwg_inputs() {
  jQuery(".spider_int_input").keypress(function (event) {
    var chCode1 = event.which || event.paramlist_keyCode;
    if (chCode1 > 31 && (chCode1 < 48 || chCode1 > 57) && (chCode1 != 46) && (chCode1 != 45)) {
      return false;
    }
    return true;
  });
}

function bwg_show_hide_roles() {
  if(jQuery("select[name='permissions']").val() == "Administrator"){
    jQuery(".bwg_roles").hide();
  }
  else{
    jQuery(".bwg_roles").show();
  }
}

function bwg_enable_disable(display, id, current) {
  jQuery("#" + current).attr('checked', 'checked');
  jQuery("#" + id).css('display', display);
  if(id == 'tr_slideshow_title_position') {
    jQuery("#tr_slideshow_full_width_title").css('display', display);
  }
}

function bwg_change_album_view_type(type) {
  if (type == 'thumbnail') {
    jQuery("#album_thumb_dimensions").html('Album thumb dimensions: ');
	jQuery("#album_thumb_dimensions_x").css('display', '');
	jQuery("#album_thumb_height").css('display', '');
  }
  else {
    jQuery("#album_thumb_dimensions").html('Album thumb width: ');
    jQuery("#album_thumb_dimensions_x").css('display', 'none');
	jQuery("#album_thumb_height").css('display', 'none');
  }
}

function spider_check_isnum(e) {
  var chCode1 = e.which || e.paramlist_keyCode;
  if (chCode1 > 31 && (chCode1 < 48 || chCode1 > 57) && (chCode1 != 46) && (chCode1 != 45)) {
    return false;
  }
  return true;
}

function bwg_gallery_type(instagram_client_id) {
  var response = true;
  var value = jQuery('#gallery_type').val();
  response = bwg_change_gallery_type(value, 'change', instagram_client_id);
  return response;
}
function bwg_gallery_update_flag(){
  var update_flag = jQuery('#tr_update_flag input[name=update_flag]:checked').val();
  if(update_flag == ''){
    jQuery('.spider_delete_button').show();
    /*
    jQuery("[id^=image_alt_text_]").prop("readonly",false);
    jQuery("[id^=image_description_]").prop("readonly",false);
    jQuery("[id^=redirect_url_]").prop("readonly",false);
    */
  }
  else{
    jQuery('.spider_delete_button').hide();
    /*
    jQuery("[id^=image_alt_text_]").prop("readonly", true);
    jQuery("[id^=image_description_]").prop("readonly", true);
    jQuery("[id^=redirect_url_]").prop("readonly", true);
    */
  }
}

bwg_gallery_change_update_flag = jQuery(function () {
    jQuery('#tr_update_flag input[name=update_flag]').change(function(){
      bwg_gallery_update_flag();
      /*var update_flag = jQuery(this).val(); */
    });
});

/*returns false if user cancels or impossible to do.*/
/*
   type_to_set:'' or 'instagram'
*/
function bwg_change_gallery_type(type_to_set, warning_type, instagram_client_id) {
  warning_type = (typeof warning_type === "undefined") ? "default" : warning_type;

  if (type_to_set == 'instagram') {
    if (instagram_client_id == '') {
        alert(bwg_objectL10B.bwg_access_token);
        jQuery('#gallery_type').val('');
        return false;
    }
    if (!bwg_check_gallery_empty(true, true)) {
      return false;
    }

    jQuery("#add_facebook_gallery").hide();
    jQuery("#add_instagram_gallery").show();

    jQuery('#gallery_type').val('instagram');
    jQuery('#tr_instagram_post_gallery').show();

    /*hide features of only mixed gallery*/
    jQuery('.spider_delete_button').hide();
    jQuery('#spider_resize_button').hide();
    jQuery('#content-add_media').hide();
    jQuery('#show_add_embed').hide();
    jQuery('#show_bulk_embed').hide();
  }
  else if(type_to_set == 'facebook') {
    if (!bwg_check_gallery_empty(true, true)) {
      return false;
    }
    jQuery('#add_facebook_gallery').show();
    jQuery("#add_instagram_gallery").hide();

    jQuery('#gallery_type').val('facebook');
    jQuery('#tr_instagram_post_gallery').hide();

    /*hide features of only mixed gallery*/
    jQuery('.spider_delete_button').hide();
    jQuery('#spider_resize_button').hide();
    jQuery('#content-add_media').hide();
    jQuery('#show_add_embed').hide();
    jQuery('#show_bulk_embed').hide();

    /*reset update_flag radio button*/
    jQuery("#update_flag_0").attr('checked', 'checked');
    bwg_gallery_update_flag();
    jQuery('#tr_update_flag').hide();
    jQuery('#tr_autogallery_image_number').hide();
    jQuery('#tr_instagram_gallery_add_button').hide();
    //default limit 20
    jQuery("#facebook_gallery_image_limit").val(20);
  }
  else {
    var ids_string = jQuery("#ids_string").val();
    ids_array = ids_string.split(",");
    var tr_count = ids_array[0]=='' ? 0: ids_array.length;
    if(tr_count != 0){
      switch(warning_type) {
        case 'default':
          var allowed = confirm(bwg_objectL10B.default_warning);
          break;
        case 'change':
          var allowed = confirm(bwg_objectL10B.change_warning);
          break;
        default:
          var allowed = confirm(bwg_objectL10B.other_warning);
      }

      if (allowed == false) {
        jQuery('#gallery_type').val('instagram');
        return false;
      }
    }

    jQuery('#gallery_type').val('');
    jQuery('#tr_instagram_post_gallery').hide();

    /*reset update_flag radio button*/
    jQuery("#update_flag_0").attr('checked', 'checked');
    bwg_gallery_update_flag();

    /*show features of only mixed gallery*/
    jQuery('.spider_delete_button').show();
    jQuery('#spider_resize_button').show();
    jQuery('#content-add_media').show();
    jQuery('#show_add_embed').show();
    jQuery('#show_bulk_embed').show();

    jQuery('#add_facebook_gallery').hide();
    jQuery("#add_instagram_gallery").hide();
  }
  return true;
}

/*bulk embed handling*/
function bwg_bulk_embed(from, key){
    switch (from) {
        case 'instagram' : {
            bwg_add_instagram_gallery(key, true);
            break;
        }
        case 'facebook' : {
            var appkey = key.split('|');
            bwg_add_facebook_gallery(true, appkey[0], appkey[1]);
            break;
        }
    }
    return "";
}

function bwg_check_instagram_gallery_input(instagram_client_id, from_popup){
  from_popup = typeof from_popup !== 'undefined' ? from_popup : false;
  var is_error = false;
  if(from_popup){
    if(instagram_client_id == ''){
      alert(bwg_objectL10B.bwg_access_token);
      is_error = true;
    }
    if( spider_check_required('popup_instagram_gallery_source', 'Instagram user URL')){
      is_error = true;
    }
    if (jQuery('#popup_instagram_image_number').val() > 33 ||jQuery('#popup_instagram_image_number').val() < 1 ) {
      alert(bwg_objectL10B.bwg_post_number);
      jQuery('#popup_instagram_image_number').attr('style', 'border-color: #FF0000;');
      jQuery('#popup_instagram_image_number').focus();
      jQuery('html, body').animate({
        scrollTop:jQuery('#popup_instagram_image_number').offset().top - 200
      }, 500);
      is_error = true;
    }
  }
  else{
	  if (bwg_is_instagram_gallery()){
	    if(instagram_client_id == ''){
	      alert(bwg_objectL10B.bwg_access_token);
	      is_error = true;
	    }

      if(jQuery('#autogallery_image_number').val() > 33 || jQuery('#autogallery_image_number').val() < 1 ){

        alert(bwg_objectL10B.bwg_post_number);
        jQuery('#autogallery_image_number').attr('style', 'border-color: #FF0000;');
        jQuery('#autogallery_image_number').focus();
        jQuery('html, body').animate({
          scrollTop:jQuery('#autogallery_image_number').offset().top - 200
        }, 500);
        is_error = true;
      }
	}
  }
  return is_error;
}

function bwg_is_instagram_gallery() {
  var value = jQuery('#gallery_type').val();
  if(value == 'instagram'){
    return true;
  }
  else{
    return false;
  }
}

/**
 *
 *  @param reset:bool true if reset to mixed in case of not empty
 *  @param message:bool true if to alert that not empty
 *  @return true if empty, false if not empty
 */
function bwg_check_gallery_empty(reset, message) {
  var ids_string = jQuery("#ids_string").val();
  var ids_array = ids_string.split(",");
  var tr_count = ids_array[0]=='' ? 0: ids_array.length;
  if(tr_count != 0){
    if(reset){
      if(message){
        alert(bwg_objectL10B.bwg_not_empty);
      }
      jQuery('#gallery_type').val('');
      jQuery('#tr_instagram_post_gallery').hide();
      jQuery('#tr_gallery_source').hide();
      jQuery('#tr_update_flag').hide();
      jQuery('#tr_autogallery_image_number').hide();
      jQuery('#tr_instagram_gallery_add_button').hide();
    }
    else{
      if(message) {
        alert(bwg_objectL10B.bwg_not_empty);
      }
    }
    return false;
  }
  else {
    return true;
  }
}

function bwg_convert_seconds(seconds) {
  var sec_num = parseInt(seconds, 10);
  var hours   = Math.floor(sec_num / 3600);
  var minutes = Math.floor((sec_num - (hours * 3600)) / 60);
  var seconds = sec_num - (hours * 3600) - (minutes * 60);

  if (minutes < 10 && hours != 0) {minutes = "0" + minutes;}
  if (seconds < 10) {seconds = "0" + seconds;}
  var time    = (hours != 0 ? hours + ':' : '') + minutes + ':' + seconds;
  return time;
}

function bwg_convert_date(date, separator) {
  var m_names = new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
  date = date.split(separator);
  var dateArray = date[0].split("-");
  return dateArray[2] + " " + m_names[dateArray[1] - 1] + " " + dateArray[0] + ", " + date[1].substring(0, 5);
}

/* EMBED handling */
function bwg_get_embed_info(input_id) {
  jQuery('#loading_div').show();
  var url = encodeURI(jQuery("#" + input_id).val());
  if (!url) {
    alert(bwg_objectL10B.bwg_enter_url);
    return '';
  }
  var filesValid = [];
  var data = {
    'action': 'addEmbed',
    'URL_to_embed': url,
    'async':true
  };


   // get from the server data for the url. Here we use the server as a proxy, since Cross-Origin Resource Sharing AJAX is forbidden.
  jQuery.post(ajax_url, data, function(response) {
    if(response == false){
      alert(bwg_objectL10B.bwg_cannot_response);
      jQuery('#loading_div').hide();
      return '';
    }
    else {
      var index_start = response.indexOf("WD_delimiter_start");
      var index_end = response.indexOf("WD_delimiter_end");
      if(index_start == -1 || index_end == -1){
        alert(bwg_objectL10B.bwg_something_wrong);
        jQuery('#loading_div').hide();
        return '';
      }

      /*filter out other echoed characters*/
      /*18 is the length of "wd_delimiter_start"*/
      response = response.substring(index_start+18,index_end);

      response_JSON = jQuery.parseJSON(response);
        /*if indexed array, it means there is error*/
      if(typeof response_JSON[0] !== 'undefined'){
        alert(bwg_objectL10B.bwg_error + jQuery.parseJSON(response)[1]);
        jQuery('#loading_div').hide();
        return '';
      }
      else{
        fileData = response_JSON;
        filesValid.push(fileData);
        bwg_add_image(filesValid);
        document.getElementById(input_id).value = '';
        jQuery('#loading_div').hide();
        return 'ok';
      }
    }
    return '';

  });
  return 'ok';
}

function bwg_change_fonts(cont, google_fonts) {
  var fonts;
  if (jQuery("#" + google_fonts).is(":checked") == true) {
    fonts = bwg.google_fonts;
  }
  else {
    fonts = {'arial' : 'Arial', 'lucida grande' : 'Lucida grande', 'segoe ui' : 'Segoe ui', 'tahoma' : 'Tahoma', 'trebuchet ms' : 'Trebuchet ms', 'verdana' : 'Verdana', 'cursive' : 'Cursive', 'fantasy' : 'Fantasy', 'monospace' : 'Monospace', 'serif' : 'Serif'};
  }
  var fonts_option = "";
  for (var i in fonts) {
    fonts_option += '<option value="' + i + '">' + fonts[i] + '</option>';
  }
  jQuery("#" + cont).html(fonts_option);
}

/**
 * Open Wordpress media uploader.
 *
 * @param e
 * @param multiple
 */
function spider_media_uploader(e, multiple) {
  if ( typeof multiple == "undefined" ) {
    var multiple = false;
  }
  var custom_uploader;
  e.preventDefault();
  // If the uploader object has already been created, reopen the dialog.
  if ( custom_uploader ) {
    custom_uploader.open();
  }

  custom_uploader = wp.media.frames.file_frame = wp.media( {
    title: bwg_objectL10B.choose_images,
    library: { type: 'image' },
    button: { text: bwg_objectL10B.insert },
    multiple: multiple
  } );
  // When a file is selected, grab the URL and set it as the text field's value
  custom_uploader.on( 'select', function () {
    if ( multiple == false ) {
      attachment = custom_uploader.state().get( 'selection' ).first().toJSON();
    }
    else {
      attachment = custom_uploader.state().get( 'selection' ).toJSON();
    }

    var filesSelectedML = [];
    for ( var image in attachment ) {
      var image_url = attachment[image].url;
      image_url = image_url.replace( bwg_objectL10B.wp_upload_dir.baseurl + '/', '' );
      filesSelectedML.push( image_url );
    }
    jQuery( '#loading_div' ).show();

    postImageUrls(filesSelectedML, function (success, result) {
      jQuery( '#loading_div' ).hide();

      if (success) {
        for ( var i in result ) {
          result[i].alt = attachment[i].alt ? attachment[i].alt : attachment[i].title;
          result[i].description = attachment[i].description;
        }
        bwg_add_image( result );
      }
      else {
        alert( bwg_objectL10B.import_failed );
      }
    });

    function postImageUrls(imageUrls, callback, index, results) {
      var imagesChunkLength = 50;

      if (!index) {
        index = 0;
      }
      if (!results) {
        results = [];
      }

      var imageUrlsChunk = imageUrls.slice(index, index + imagesChunkLength);
      index += imagesChunkLength;
      jQuery.ajax( {
        url: bwg_objectL10B.ajax_url,
        type: "POST",
        dataType: "json",
        data: {
          action: "bwg_UploadHandler",
          file_namesML: JSON.stringify(imageUrlsChunk),
          import: 1
        },
        success: function ( result ) {
          results = results.concat(result);

          if (index < imageUrls.length) {
            postImageUrls(imageUrls, callback, index, results);
          }
          else {
            callback(true, results);
          }
        },
        error: function ( xhr ) {
          callback(false);
        }
      } );
    }
  } );

  // Open the uploader dialog.
  custom_uploader.open();
}

/**
 * Search.
 *
 * @param that
 */
function search(that) {
  var form = jQuery(that).parents("form");

  if ( form.attr("id") == "bwg_gallery" ) { // Gallery edit page.
    jQuery("#paged").val(1);
    jQuery("#ajax_task").val('ajax_apply');
    spider_ajax_save(form.attr("id"));
  }
  else {
    var action = form.attr("action");
    form.attr("action", action + "&paged=1&s=" + jQuery("input[name='s']").val());

    form.submit();
  }
}

/**
 * Search on input enter.
 *
 * @param e
 * @param that
 * @returns {boolean}
 */
function input_search(e, that) {
  var key_code = (e.keyCode ? e.keyCode : e.which);
  if (key_code == 13) { /*Enter keycode*/
    search(that);
    return false;
  }
}

/**
 * Change page on input enter.
 *
 * @param e
 * @param that
 * @returns {boolean}
 */
function input_pagination(e, that) {
  var key_code = (e.keyCode ? e.keyCode : e.which);
  if (key_code == 13) { /*Enter keycode*/
    var to_page = jQuery(that).val();
    var pages_count = jQuery(that).parents(".pagination-links").data("pages-count");
    var form = jQuery(that).parents("form");
    if ( form.attr("id") == "bwg_gallery" ) { // Gallery edit page.
      if (to_page > pages_count) {
        to_page = 1;
      }
      jQuery("#paged").val(to_page);
      jQuery("#ajax_task").val('ajax_apply');
      spider_ajax_save(form.attr("id"));
      return false;
    }
    else {
      if (to_page <= pages_count) {
        var search = jQuery("input[name='s']").val() ? ("&s=" + jQuery("input[name='s']").val()) : "";
        var action = form.attr("action");
        form.attr("action", action + "&paged=" + to_page + search);
      }
      form.submit();
    }
  }
  return true;
}

/**
 * Bulk actions.
 *
 * @param that
 */
function wd_bulk_action(that) {
  var form = jQuery(that).parents("form");
  var action = jQuery("select[name='" + ( form.attr("id") == "bwg_gallery" ? 'image_' : '' ) + "bulk_action']").val();

  if (action != -1) {
    if (!jQuery("input[name^='check']").is(':checked')) {
      alert(bwg.select_at_least_one_item);
      return;
    }
    if (action == 'delete') {
      if (!confirm(bwg.delete_confirmation)) {
        return false;
      }
    }
    else if (action == 'image_resize') {
      jQuery(".opacity_resize_image").show();
      return false;
    }
    else if (action == 'image_edit') {
      jQuery(".opacity_image_desc").show();
      return false;
    }
    else if (action == 'image_add_tag') {
      jQuery(".wd-add-tags").trigger("click");
      return;
    }
    else if (action == 'set_image_pricelist') {
      jQuery(".wd-add-pricelist").trigger("click");
      return;
    }
    else if (action == 'remove_pricelist_all') {
      if (!confirm(bwg.remove_pricelist_confirmation)) {
        return false;
      }
    }
    if ( form.attr("id") == "bwg_gallery" ) { // Gallery edit page.
      jQuery("input[name='task']").val("save");
      jQuery("input[name='ajax_task']").val(action);
      spider_ajax_save(form.attr("id"));
    }
    else {
      jQuery("input[name='task']").val(action);
      form.submit();
    }
  }
}

function bwg_change_theme_tab_item() {
	var id = jQuery('.bwg-tabs .bwg-tab-item.active').attr('data-id');
	jQuery('fieldset#'+ id).show();

	jQuery(document).on('click', '.bwg-tabs .bwg-tab-item', function () {
		jQuery('.bwg-tabs .bwg-tab-item').removeClass('active');
		jQuery(this).addClass('active');
		var id = jQuery(this).attr('data-id');
		jQuery('.spider_type_fieldset').hide();
		jQuery('#'+ id ).show();
		jQuery('#active_tab').val(jQuery(this).attr('data-id'));
	});
}

function bwg_filters() {
	jQuery(document).on('change','select[id^=filter-by]', function(){
		var val = jQuery(this).val();
		var id  = jQuery(this).attr('id');
		window.location.href = bwg_updateQueryStringParameter(window.location.href, id, val);
	});
}

function bwg_updateQueryStringParameter(uri, key, value) {
  var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
  var separator = uri.indexOf('?') !== -1 ? "&" : "?";
  if (uri.match(re)) {
    return uri.replace(re, '$1' + key + "=" + value + '$2');
  }
  else {
    return uri + separator + key + "=" + value;
  }
}

// Open/close section container on its header click.
function bwg_toggle_postbox() {
	jQuery(".hndle, .handlediv").each(function () {
		jQuery(this).on("click", function () {
		  jQuery(this).parent(".postbox").toggleClass("closed");
		});
	});
}

function spider_select_value(obj) {
  obj.focus();
  obj.select();
}

function how_to_use() {
  jQuery(".how_to_postbox").removeClass("closed");
  jQuery('html, body').animate({
    scrollTop: jQuery(".how_to_postbox").offset().top - 40
  }, 300);
}

var j_int = 0;
var bwg_j = 'pr_' + j_int;

/**
 * Add image to images list.
 *
 * @param files
 */
function bwg_add_image(files) {
  // Pointer. // ToDO
  //jQuery(document).trigger("bwgImagesAdded");
  for ( var i in files ) {
    var is_embed = files[i]['filetype'].indexOf("EMBED_") > -1 ? true : false;
    var is_direct_url = files[i]['filetype'].indexOf("DIRECT_URL_") > -1 ? true : false;
    var is_facebook_post = files[i]['filetype'].indexOf("_FACEBOOK_POST") > -1 ? 1 : 0;
    var fb_post_url = (is_facebook_post) ? files[i]['filename'] : '';
	var instagram_post_width  = files[i]['resolution'].split(' x ')[0];
	var instagram_post_height = files[i]['resolution'].split(' x ')[1].split(' ')[0];

    var html = jQuery(".wd-template").clone().html();
    html = html.replace(/tempid/g, bwg_j)
        .replace(/tempnum/g, 1)
        .replace(/tempimage_url/g, files[i]['url'])
        .replace(/tempthumb_url/g, files[i]['thumb_url'])
        .replace(/tempthumb_src=""/g, 'src="' + files[i]['thumb'] + '"')
        .replace(/tempfilename/g, files[i]['filename'])
        .replace(/tempdate/g, files[i]['date_modified'])
        .replace(/tempresolution/g, files[i]['resolution'])
        .replace(/temp_instagram_post_width/g, instagram_post_width)
        .replace(/temp_instagram_post_height/g, instagram_post_height)
        .replace(/tempsize/g, files[i]['size'])
        .replace(/tempfiletype/g, files[i]['filetype'])
        .replace(/tempis_facebook_post/g, (is_facebook_post ? files[i]['is_facebook_post'] : 0))
        .replace(/tempfb_post_url/g, (is_facebook_post ? files[i]['fb_post_url'] : 0));
    if ( is_embed ) {
      html = html.replace(/tempalt/g, files[i]['name']);
      jQuery(".wd-image-actions").addClass("wd-hide");
    }
    else {
      html = html.replace(/tempalt/g, files[i]['alt']);
    }
    var description = files[i]['description'] ? files[i]['description'] : '';
    if ( jQuery("#tbody_arr").data("meta") == 1 && !is_embed ) {
      description += files[i]['description'] ? '\n' : '';
      description += files[i]['credit'] ? 'Author: ' + files[i]['credit'] + '\n' : '';
      description += ((files[i]['aperture'] != 0 && files[i]['aperture'] != '') ? 'Aperture: ' + files[i]['aperture'] + '\n' : '');
      description += ((files[i]['camera'] != 0 && files[i]['camera'] != '') ? 'Camera: ' + files[i]['camera'] + '\n' : '');
      description += ((files[i]['caption'] != 0 && files[i]['caption'] != '') ? 'Caption: ' + files[i]['caption'] + '\n' : '');
      description += ((files[i]['iso'] != 0 && files[i]['iso'] != '') ? 'Iso: ' + files[i]['iso'] + '\n' : '');
      description += ((files[i]['copyright'] != 0 && files[i]['copyright'] != '') ? 'Copyright: ' + files[i]['copyright'] + '\n' : '');
      description += ((files[i]['orientation'] != 0 && files[i]['orientation'] != '') ? 'Orientation: ' + files[i]['orientation'] + '\n' : '');
    }
    html = html.replace(/tempdescription/g, description);

    jQuery("#tbody_arr").prepend("<tr id='tr_" + bwg_j + "'>");
    jQuery("#tr_" + bwg_j).html(html);

    jQuery("#ids_string").val(jQuery("#ids_string").val() + bwg_j + ',');

    j_int++;
    bwg_j = 'pr_' + j_int;
  }
  // Add drag and drop to new rows.
  wd_showhide_weights();
  // Set order input values after adding rows.
  var i = jQuery("td.col_drag").data("page-number");
  jQuery(".wd-order").each(function () {
    jQuery(this).val(++i);
  });
  // Set number column values after adding rows.
  var i = 0;
  jQuery("#tbody_arr .col_num").each(function () {
    jQuery(this).html(++i);
  });
  window.parent.jQuery(".no-items").remove();
  jQuery(".unsaved-msg", window.parent.document).removeClass("wd-hide");
  jQuery(".ajax-msg", window.parent.document).addClass("wd-hide");
}

/**
 * Change pagination to ajax pagination.
 */
function wd_pagination() {
  jQuery("#bwg_gallery a.wd-page ").each(function () {
    jQuery(this).removeAttr("href");
    jQuery(this).on("click", function() {
      var paged = jQuery(this).data("paged");
      jQuery("#paged").val(paged);
      jQuery("#ajax_task").val('ajax_apply');
      spider_ajax_save('bwg_gallery');
    });
  });
}

function bwg_tb_window(id) {
  if (typeof id === 'undefined') {
    var id = '';
  }
  var thickDims, tbWidth, tbHeight;
  thickDims = function () {
    var tbWindow = jQuery('#TB_window'), H = jQuery(window).height(), W = jQuery(window).width(), w, h;
    w = (tbWidth && tbWidth < W - 90) ? tbWidth : W - 40;
    h = (tbHeight && tbHeight < H - 60) ? tbHeight : H - 40;
    if (tbWindow.size()) {
      tbWindow.width(w).height(h);
      jQuery('#TB_iframeContent').width(w).height(h - 30);
      tbWindow.css({'margin-left': '-' + parseInt((w / 2), 10) + 'px'});
      if (typeof document.body.style.maxWidth != 'undefined') {
        tbWindow.css({'top': (H - h) / 2, 'margin-top': '0'});
      }
    }
  };
  thickDims();
  jQuery(window).resize(function () {
    thickDims()
  });
  jQuery('a.thickbox-preview' + id).click(function () {
    tb_click.call(this);
    var alink = jQuery(this).parents('.available-theme').find('.activatelink'), link = '', href = jQuery(this).attr('href'), url, text;
    if (tbWidth = href.match(/&width=[0-9]+/)) {
      tbWidth = parseInt(tbWidth[0].replace(/[^0-9]+/g, ''), 10);
    }
    else {
      tbWidth = jQuery(window).width() - 120;
    }

    if (tbHeight = href.match(/&height=[0-9]+/)) {
      tbHeight = parseInt(tbHeight[0].replace(/[^0-9]+/g, ''), 10);
    }
    else {
      tbHeight = jQuery(window).height() - 120;
    }
    if (alink.length) {
      url = alink.attr('href') || '';
      text = alink.attr('title') || '';
      link = '&nbsp; <a href="' + url + '" target="_top" class="tb-theme-preview-link">' + text + '</a>';
    }
    else {
      text = jQuery(this).attr('title') || '';
      link = '&nbsp; <span class="tb-theme-preview-link">' + text + '</span>';
    }
    // jQuery('#TB_title').css({'background-color': '#222', 'color': '#dfdfdf'});
    jQuery('#TB_closeAjaxWindow').css({'float': 'right'});
    jQuery('#TB_ajaxWindowTitle').css({'float': 'left'}).html(link);
    jQuery('#TB_iframeContent').width('100%');
    thickDims();
    return false;
  });
  // Theme details
  jQuery('.theme-detail').click(function () {
    jQuery(this).siblings('.themedetaildiv').toggle();
    return false;
  });
}

// Prevent new line.
function prevent_new_line(e) {
  if ( e.keyCode == 13 ) {
    e.preventDefault();
    return false;
  }
}

function bwg_gallery_type_options(gallery_type) {
  if (gallery_type === undefined) {
    gallery_type = jQuery('#gallery_type').val();
  }
  jQuery('.gallery_options').hide();
  jQuery('#' + gallery_type + '_options').show();
  jQuery('#gallery_type').val(gallery_type);
  if ( jQuery(".wd-free-msg").length != 0 ) {
    jQuery(".wd-free-msg").hide();
    jQuery(".bwg-pro-views").hide();
    if (jQuery('#' + gallery_type + '_options').hasClass("bwg-pro-views")) {
      jQuery(".wd-free-msg").show();
    }
  }
  jQuery('input[name=gallery_type][id=' + gallery_type + ']').attr('checked', 'checked');
}

function bwg_album_type_options(album_type) {
  if (album_type === undefined) {
    album_type = jQuery('#album_type').val();
  }
  jQuery('.album_options').hide();
  jQuery('#' + album_type + '_options').show();
  jQuery('#album_type').val(album_type);
  if ( jQuery(".wd-free-msg").length != 0 ) {
    jQuery(".wd-free-msg").hide();
    jQuery(".bwg-pro-views").hide();
    if (jQuery('#' + album_type + '_options').hasClass("bwg-pro-views")) {
      jQuery(".wd-free-msg").show();
    }
  }
  jQuery('input[name=album_type][id=' + album_type + ']').attr('checked', 'checked');
}

function bwg_pagination_description(that) {
  obj = jQuery(that);
  obj.closest('.wd-group').find('.description').hide();
  jQuery('#' + obj.attr('name') + '_' + obj.val() + '_description').show();
}

function bwg_thumb_click_action(  ) {
  if (jQuery("#thumb_click_action_2").is(':checked')) {
    jQuery('.bwg-lightbox-redirect').show();
  }
  else {
    jQuery('.bwg-lightbox-redirect').hide();
  }
}
<?php

require_once BWG()->plugin_dir . '/frontend/controllers/BWGControllerShare.php';

$controller = new BWGControllerShare();
$controller->execute();